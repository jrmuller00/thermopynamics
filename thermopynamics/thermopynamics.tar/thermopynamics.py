import fluids

fluids.main()

